<?php $__env->startSection('content'); ?>

<div style="max-width: 800px; margin: 0 auto; padding: 20px; background-color: #fff; box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1); border-radius: 8px;">

    <!-- Pesan Sukses -->
    <?php if(session('success')): ?>
        <div style="padding: 10px; margin-bottom: 20px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 5px;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <h1 style="text-align: center; margin: 20px 0;"><?php echo e($recipe->name); ?></h1>
    <img
        src="<?php echo e(asset('storage/' . $recipe->image)); ?>"
        alt="<?php echo e($recipe->name); ?>"
        style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;"
    >

    <h2 style="color: #333;">Deskripsi</h2>
    <p style="font-size: 16px; color: #555;"><?php echo e($recipe->description); ?></p>

    <h2 style="color: #333;">Cuisine</h2>
    <p style="font-size: 16px; color: #555;"><?php echo e($recipe->cuisine); ?></p>

    <h2 style="color: #333;">Tipe Makanan (menit)</h2>
    <p style="font-size: 16px; color: #555;"><?php echo e($recipe->meal_course); ?></p>

    <h2 style="color: #333;">Waktu Masak</h2>
    <p style="font-size: 16px; color: #555;"><?php echo e($recipe->time); ?> minutes</p>

    <h2 style="color: #333;">Asal Negara</h2>
    <p style="font-size: 16px; color: #555;"><?php echo e($recipe->origin); ?></p>

    <h2 style="color: #333;">Tingkat Kesulitan</h2>
    <p style="font-size: 16px; color: #555;"><?php echo e($recipe->difficulty); ?></p>

    <h2 style="color: #333;">Bahan - bahan</h2>
    <ul style="font-size: 16px; color: #555;">
        <?php $__currentLoopData = $recipe->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($ingredient->name); ?> - <?php echo e($ingredient->quantity); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h2 style="color: #333;">Langkah - langkah</h2>
    <ol style="font-size: 16px; color: #555;">
        <?php $__currentLoopData = $recipe->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($step->description); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

    <h2 style="color: #333;">Peralatan</h2>
    <ul style="font-size: 16px; color: #555;">
        <?php $__currentLoopData = $recipe->equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($equipment->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <!-- Back & Edit Buttons -->
    <div style="text-align: left; margin-top: 20px; display: flex; gap: 10px;">
        <a href="<?php echo e(route('allRecipes')); ?>" class="btn btn-primary" style="padding: 10px 20px; background-color: #007BFF; color: white; text-decoration: none; border-radius: 5px;">
            Kembali
        </a>
        <a href="<?php echo e(route('recipe.edit', ['id' => $recipe->id])); ?>" class="btn btn-success" style="padding: 10px 20px; background-color: #42d565; color: white; text-decoration: none; border-radius: 5px;">
            Edit Resep
        </a>
        <a href="<?php echo e(route('delete.confirmation', $recipe->id)); ?>" class="btn btn-uccess" style="padding: 10px 20px; background-color: #e24f44; color: white; text-decoration: none; border-radius: 5px;">
            Hapus Resep
        </a>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProg - Copy\resources\views/recipesDetails.blade.php ENDPATH**/ ?>